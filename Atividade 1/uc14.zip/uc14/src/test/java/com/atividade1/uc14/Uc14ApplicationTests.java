package com.atividade1.uc14;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Uc14ApplicationTests {

	@Test
	void contextLoads() {
	}

}
