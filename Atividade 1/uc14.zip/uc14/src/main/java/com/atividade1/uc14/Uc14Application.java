package com.atividade1.uc14;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Uc14Application {

	public static void main(String[] args) {
		SpringApplication.run(Uc14Application.class, args);
	}

}
